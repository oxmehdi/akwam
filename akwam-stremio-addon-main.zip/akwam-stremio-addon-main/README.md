# Akwam Stremio Addon

A Stremio addon that scrapes Akwam.to for educational purposes.

## 🚀 Deploy on Render

1. Push this repo to your GitHub
2. Go to [https://render.com](https://render.com)
3. Create a new **Web Service** from this repo
4. Use:
   - Build command: `npm install`
   - Start command: `npm start`
5. Done! Access your manifest at `https://your-app.onrender.com/manifest.json`